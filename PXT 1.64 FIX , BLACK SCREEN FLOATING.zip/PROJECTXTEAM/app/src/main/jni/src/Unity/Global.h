
#ifndef ANDROID_MOD_MENU_GLOBAL_H
#define ANDROID_MOD_MENU_GLOBAL_H

struct {
    
    uintptr_t HeadTF = 0x1E8;//[1.64.4]  public Transform JoqBDUR
    uintptr_t HipTF = 0x1EC;//[1.64.4]  protected Transform gBb{jci
    uintptr_t HandTF = 0x1E4;//[1.64.4]  protected Transform yFayxSS
    uintptr_t ToeTF = 0x1FC;//[1.64.4]  protected Transform `}Klj
    uintptr_t PeS = 0x20C;//[1.64.4]  protected Transform oporBaB
    uintptr_t PeD = 0x210;//[1.64.4]  protected Transform lpF[hWQ
    uintptr_t DedoTF = 0x214;//[1.64.4]  protected Transform yvZ[NRv
    uintptr_t LShoulder = 0x218;//[1.64.4]  protected Transform iuhFwSC
    uintptr_t RShoulder = 0x21C;//[1.64.4]  protected Transform IcoOWF
    
    
    uintptr_t Vehicle = 0x2CC; 
	
    uintptr_t MainCameraTransform = 0x6C;//[1.64.4]  public Transform MainCameraTransform
    uintptr_t Dictionary = 0x44;//[1.64.4]
    uintptr_t IsClientBot = 0xF0;//[1.64.4]  public bool IsClientBot
    
    // 1.64
    uintptr_t LineRenderer_Set_PositionCount = 0x2A91AB4;//public void set_positionCount(int value) { } 1.64
    uintptr_t LineRenderer_SetPosition = 0x2A91B60;//public void SetPosition(int index, Vector3 position) { } 1.64
    uintptr_t GrenadeLine_DrawLine = 0xC78EC8;//private void DrawLine(Vector3 throwPos, Vector3 throwVel, Vector3 gravity) { } 1.64
    uintptr_t GrenadeLine_Update = 0xC78B78;// 1.64
    uintptr_t get_imo = 0x8B554C;//public ytMNhlw GetActiveWeapon() { } 1.64
    uintptr_t set_esp = 0x1585250;//public void utKBmvc(Vector3 RvOJF{, Vector3 bQiMI) { } 1.64
    uintptr_t U3DStr = 0x2982200;//private string CreateString(sbyte* value) { } 1.64
    uintptr_t CurrentUIScene = 0x9D9388;//public static UICOWBaseScene CurrentUIScene() { } 1.64
    uintptr_t WorldToScreenPoint = 0x29E83A8;//1.64
    uintptr_t Component_GetTransform = 0x29EA594;   //1.64
    uintptr_t Transform_INTERNAL_GetPosition = 0x2C345B8;//1.64
    uintptr_t Transform_INTERNAL_SetPosition = 0x2C34658;//1.64
    uintptr_t GetAttackableCenterWS = 0x8B8610;//1.64
    uintptr_t get_NickName = 0x8B8BA8;//1.64
    uintptr_t get_MyFollowCamera = 0x8B96E8;//1.64
    uintptr_t Curent_Match = 0x9D9EA4;//1.64
    uintptr_t GetLocalPlayerOrObServer = 0x9DB890;//1.64
    uintptr_t Current_Local_Player = 0x9DA1C8;//1.64
    uintptr_t Camera_main = 0x29E8A98;//1.64
    uintptr_t set_aim = 0x8B9EEC;//1.64
    uintptr_t GetForward = 0x2C35118;//1.64
    uintptr_t GetLocalPlayer = 0xA24FC0;//1.64
    uintptr_t get_IsSighting = 0x91EAC0;//1.64
    uintptr_t get_isLocalTeam = 0x8C2D18;//1.64
    uintptr_t get_isVisible = 0x8BBFC4;//1.64
    uintptr_t get_isAlive = 0x90C454;//1.64
    uintptr_t get_IsDieing = 0x8B966C;//1.64
    uintptr_t get_IsCrouching = 0x8B966C;//1.64
    uintptr_t get_MaxHP = 0x8F1FEC;//1.64
    uintptr_t get_IsFiring = 0x8B4944;//1.64
    uintptr_t ShowAssistantText = 0x9863A8;//1.64
    uintptr_t ShowDynamicPopupMessage = 0x96F1FC;// 1.64
    uintptr_t ShowPopupMessage = 0x96F33C;// 1.64
    
    // 1.64
    uintptr_t set_startColor = 0x2A918D4;//public void set_startColor(Color value) { }
    uintptr_t set_endColor = 0x2A91978;//public void set_endColor(Color value) { }
	// 1.64
	uintptr_t Raycast = 0x3818CEC; //public static bool Raycast(Vector3 origin, Vector3 direction, float maxDistance, int layerMask) { }

} Global;

#endif




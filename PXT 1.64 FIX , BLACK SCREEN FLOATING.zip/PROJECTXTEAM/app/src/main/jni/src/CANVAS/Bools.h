#ifndef BOOLS_H
#define BOOLS_H

#include <jni.h>
#include <string>
#include <cstdlib>
#include <unistd.h>
#include <sys/mman.h>
#include <android/log.h>
#include "StructsCommon.h":
bool isESP = false;
bool EspName = false;
bool EspLine2 = false;
bool isPlayerName = false;
bool isPlayerDist = false;
bool isPlayerHealth = false;
bool isTeamMateShow = false;
bool EspVidaDraw = false;
bool isPlayer360 = false;
bool isPlayerDistance = false;
bool isCrosshair = false;
bool isDrawCircle = false;
bool isPlayerCount = false;

Color LineColorBranco = Color::White();
Color LineColorPreto = Color::Black();
Color Changecolor = Color::White();
Color changecolor = Color::Black();
Color CircleColor = Color::White();



int EspCor = 0;
float CrossSize = 42;
float playerTextSize = 12;
float CircleSize = 22;
float Linesize = 2;
float MocoSize = 42;
float largura1 = 1280;
float altura1 = 720;
float largura2 = 1920;
float altura2 = 1080;
float largura3 = 2340;
float altura3 = 1080;

/// MENU ESP ///
bool EspAlert = false;
bool EspFire = false;
bool EspM = false;
bool EspLine = false;
bool EspBox = false;
bool EspCross = false;
bool EspMoco = false;
bool ESP360 = false;
bool EspAlvo = false;
bool EspPopup = false;
bool Distancia3 = false;
bool EspEsqueleto = false;
bool EspAliados = false;
bool ESPFPS = false;
bool EspPopup2 = false;
bool removerconta = false;
bool fakename = false;
bool medkit = false;
bool modonoite = false;
bool mapahd = false;
bool caidos = false;
bool isbot = false;
bool espsexo = false;
bool espcolete = false;
bool Fly = false;
bool off = false;

bool Gravity = false;
bool FlyAltura = false;
//bool Gravity = false;

int CrossHairLine = 0;
/// esp config //
int crosshairsize = 0;
int linex = 0;
int LineSize = 0;
int liney = 0;
int linesize = 0;
int lineop = 0;
int mocosize = 0;
int crosshaircolor = 0;
int mococolor = 0;
int resolucao = 0;
int crosshairop = 0;
int ESP360color = 0;
int ESP360op = 0;
int Boxcolor = 0;
int linecolor = 0;
int aliadoscolor = 0;
int mocoop = 0;
int boxop = 0;
int boxcolor = 0;
int caidoscolor = 0;
int textcolor = 0;
int textsize = 0;
int skeletocolor = 0;
int boxsize = 0;

#endif

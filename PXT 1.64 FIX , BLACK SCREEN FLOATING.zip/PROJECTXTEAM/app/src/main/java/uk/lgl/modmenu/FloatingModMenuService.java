/*
 * Credit:
 *
 * Octowolve - Mod menu: https://github.com/z3r0Sec/Substrate-Template-With-Mod-Menu
 * And hooking: https://github.com/z3r0Sec/Substrate-Hooking-Example
 * VanHoevenTR A.K.A Nixi: https://github.com/LGLTeam/VanHoevenTR_Android_Mod_Menu
 * MrIkso - Mod menu: https://github.com/MrIkso/FloatingModMenu
 * Rprop - https://github.com/Rprop/And64InlineHook
 * MJx0 A.K.A Ruit - KittyMemory: https://github.com/MJx0/KittyMemory
 * */

package uk.lgl.modmenu;

import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.graphics.PixelFormat;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.graphics.drawable.Drawable;
import android.text.Html;
import android.text.InputFilter;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.util.Base64;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import uk.lgl.modmenu.ESPView;
import java.io.File;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import android.graphics.drawable.BitmapDrawable;
import static uk.lgl.modmenu.StaticActivity.cacheDir;
import android.net.ConnectivityManager;
import java.net.HttpURLConnection;
import java.io.BufferedReader;
import java.io.InputStream;
import java.net.URL;
import android.os.AsyncTask;
import android.annotation.SuppressLint;
import java.io.InputStreamReader;
import android.widget.LinearLayout.LayoutParams;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.util.DisplayMetrics;
import android.transition.Visibility;
import java.util.Calendar;



public class FloatingModMenuService extends Service {
	final int TEXT_COLOR = Color.parseColor("#82CAFD");
    final int TEXT_COLOR_2 = Color.parseColor("#FFFFFF");
    final int BTN_COLOR = Color.parseColor("#1C262D");
    final int MENU_BG_COLOR = Color.parseColor("#DD1C2A35"); //#AARRGGBB
    final int MENU_FEATURE_BG_COLOR = Color.parseColor("#FF171E24"); //#AARRGGBB
    final int MENU_WIDTH = 290;
    final int MENU_HEIGHT = 210;
    final float MENU_CORNER = 20f;
    final int ICON_SIZE = 50;
    final float ICON_ALPHA = 0.7f; //Transparent
    private MediaPlayer FXPlayer;
    public View mFloatingView;
    private Button close;
    private Button kill;
    private LinearLayout mButtonPanel;
    public RelativeLayout mCollapsed;
    public LinearLayout mExpanded;
    private RelativeLayout mRootContainer;
    public WindowManager mWindowManager;
    public WindowManager.LayoutParams params;
    private LinearLayout patches;
    private FrameLayout rootFrame;
    private ImageView startimage;
    private LinearLayout view1;
    private LinearLayout view2;
    private LinearLayout Btns;
    private LinearLayout Btns2;
    private TextView textView3;
    private ImageView mViewImage3;
	private LinearLayout aim, esp, extra;
	private ScrollView saim, sesp, sextra;
	private LinearLayout linearLayoutPrincipal;




	//Canvas 
	private ESPView overlayView;
	public static native void DrawOn(ESPView espView, Canvas canvas);
	private WindowManager.LayoutParams espParams;

    private AlertDialog alert;
    private EditText edittextvalue;

    private static final String TAG = "Mod Menu";

    private LinearLayout.LayoutParams hr;

    //initialize methods from the native library
    public static native String Toast();

    private native String Icon();
    private native String Icon2();


    private native String Title();

    private native String Heading();

	//private ImageView ffid;

    private native boolean EnableSounds();

    private native int IconSize();
    private native int IconSize2();
    public native void Changes(int feature, int value);

    private native String[] getFeatureList();

	public String Color1() {
        return "#FFD600FF";
    }

    private String Color2() {
        return "#ff00b0ff";
    }

    private String Color3() {
        return "#FF131313";
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    //Override our Start Command so the Service doesnt try to recreate itself when the App is closed
    public int onStartCommand(Intent intent, int i, int i2) {
        return Service.START_NOT_STICKY;
    }

    private int getLayoutType() {
        if (Build.VERSION.SDK_INT >= 26) {
            return 2038;
        }
        if (Build.VERSION.SDK_INT >= 24) {
            return 2002;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            return 2005;
        }
        return 2003;
    }

	private void DrawCanvas() {
        WindowManager.LayoutParams layoutParams;
        this.espParams = layoutParams = new WindowManager.LayoutParams(-1, -1, this.getLayoutType(), 56, -3);
        layoutParams.gravity = 8388659;
        this.espParams.x = 0;
        this.espParams.y = 0;
        this.mWindowManager.addView((View)this.overlayView, (ViewGroup.LayoutParams)this.espParams);
    }



    //When this Class is called the code in this function will be executed
    @Override
    public void onCreate() {
        super.onCreate();
        //A little message for the user when he opens the app
        //Toast.makeText(this, Toast(), Toast.LENGTH_LONG).show();
        //Init Lib

        // When you change the lib name, change also on Android.mk file
        // Both must have same name
        System.loadLibrary("Loader");
		this.overlayView = new ESPView((Context)this);

        initFloating();
        CreateMenuList();
		DrawCanvas();
		//  initAlertDiag();
        final Handler handler = new Handler();
        handler.post(new Runnable() {
                public void run() {
                    handler.postDelayed(this, 1000);
                }
            });
    }

    private void initFloating() {
        rootFrame = new FrameLayout(getBaseContext()); // Global markup
        mRootContainer = new RelativeLayout(getBaseContext()); // Markup on which two markups of the icon and the menu itself will be placed
        mCollapsed = new RelativeLayout(getBaseContext()); // Markup of the icon (when the menu is minimized)
        mExpanded = new LinearLayout(getBaseContext()); // Menu markup (when the menu is expanded)
        view1 = new LinearLayout(getBaseContext());
        patches = new LinearLayout(getBaseContext());
        view2 = new LinearLayout(getBaseContext());
        mButtonPanel = new LinearLayout(getBaseContext()); // Layout of option buttons (when the menu is expanded)

        RelativeLayout relativeLayout = new RelativeLayout(this);
        relativeLayout.setLayoutParams(new RelativeLayout.LayoutParams(-2, -1));
        relativeLayout.setPadding(3, 0, 3, 3);
        relativeLayout.setVerticalGravity(16);

        kill = new Button(this);
        kill.setBackgroundColor(Color.parseColor("#00000000"));
        kill.setText("INVISÍVEL");
        kill.setTextColor(Color.parseColor("#FFFFFF"));

        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(11);

        close = new Button(this);
        close.setBackgroundColor(Color.parseColor("#00000000"));
        close.setText("MINIMIZAR");
        close.setTextColor(Color.parseColor("#FFFFFF"));
        close.setLayoutParams(layoutParams);

        relativeLayout.addView(kill);
        relativeLayout.addView(close);

        rootFrame.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        mRootContainer.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        mCollapsed.setVisibility(View.VISIBLE);
        startimage = new ImageView(getBaseContext());
        startimage.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        int applyDimension = (int) TypedValue.applyDimension(1, (float) IconSize(), getResources().getDisplayMetrics());
        startimage.getLayoutParams().height = applyDimension;
        startimage.getLayoutParams().width = applyDimension;
        startimage.requestLayout();
        startimage.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decode = Base64.decode(Icon(), 0);
        startimage.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
        ((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(10);

        mExpanded.setVisibility(View.GONE);
        mExpanded.setBackgroundColor(Color.parseColor("#000000"));
        mExpanded.setAlpha(0.95f);
        mExpanded.setGravity(17);
        mExpanded.setOrientation(LinearLayout.VERTICAL);
        mExpanded.setPadding(0, 0, 0, 0);
        //Auto size. To set size manually, change the width and height example 500, 500
        mExpanded.setLayoutParams(new LinearLayout.LayoutParams(dp(250), dp(320)));

        ScrollView scrollView = new ScrollView(getBaseContext());
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(200)));

        view1.setLayoutParams(new LinearLayout.LayoutParams(-1, 5));
        view1.setBackgroundColor(Color.parseColor("#000000"));
        patches.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        patches.setOrientation(LinearLayout.VERTICAL);
        view2.setLayoutParams(new LinearLayout.LayoutParams(-1, 5));
        view2.setBackgroundColor(Color.parseColor("#000000"));
        view2.setPadding(0, 0, 0, 10);
        mButtonPanel.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));

        //Title text
        TextView textView = new TextView(getBaseContext());
        textView.setText("PROJECTXTEAM");
        textView.setTextColor(Color.parseColor("#FFFFFF"));
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setTextSize(20.0f);
        textView.setPadding(0, 10, 0, 5);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 17;
        //textView.setLayoutParams(layoutParams2);

        //Heading text
        TextView textView2 = new TextView(getBaseContext());
        textView2.setText(Html.fromHtml("By CRISTIANO"));
        textView2.setTextColor(Color.RED);
        textView2.setTypeface(Typeface.DEFAULT_BOLD);
        textView2.setTextSize(10.0f);
        textView2.setPadding(10, 5, 10, 10);

        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams3.gravity = 17;
        textView.setLayoutParams(layoutParams2);
        textView2.setLayoutParams(layoutParams3);
        new LinearLayout.LayoutParams(-1, dp(25)).topMargin = dp(2);
        rootFrame.addView(mRootContainer);
        mRootContainer.addView(mCollapsed);
        mRootContainer.addView(mExpanded);

        mCollapsed.addView(startimage);

        mExpanded.addView(textView);
        mExpanded.addView(textView2);
        mExpanded.addView(view1);
        mExpanded.addView(scrollView);
        scrollView.addView(patches);
        mExpanded.addView(view2);
        mExpanded.addView(relativeLayout);
        mFloatingView = rootFrame;
        if (Build.VERSION.SDK_INT >= 26) {
            params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                getLayoutType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_SECURE,
                PixelFormat.TRANSLUCENT);
        } else {
            params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                getLayoutType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_SECURE,
                PixelFormat.TRANSLUCENT);
        }
        WindowManager.LayoutParams layoutParams4 = params;
        layoutParams4.gravity = 51;
        layoutParams4.x = 0;
        layoutParams4.y = 100;
        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        mWindowManager.addView(mFloatingView, params);


        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            getLayoutType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_SECURE,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;


        RelativeLayout relativeLayout2 = mCollapsed;
        LinearLayout linearLayout = mExpanded;
        mFloatingView.setOnTouchListener(onTouchListener());
        startimage.setOnTouchListener(onTouchListener());
        initMenuButton(relativeLayout2, linearLayout);

    }

    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = mCollapsed;
            final View expandedView = mExpanded;
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = motionEvent.getRawX();
                        initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - initialTouchY);

                        //The check for Xdiff <10 && YDiff< 10 because sometime elements moves a little while clicking.
                        //So that is click event.
                        if (rawX < 10 && rawY < 10 && isViewCollapsed()) {
                            //When user clicks on the image view of the collapsed layout,
                            //visibility of the collapsed layout will be changed to "View.GONE"
                            //and expanded view will become visible.
                            collapsedView.setVisibility(View.GONE);
                            expandedView.setVisibility(View.VISIBLE);
                            //Toast.makeText(FloatingModMenuService.this, Html.fromHtml(Toast()), Toast.LENGTH_SHORT).show();
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        //Calculate the X and Y coordinates of the view.
                        params.x = initialX + ((int) (motionEvent.getRawX() - initialTouchX));
                        params.y = initialY + ((int) (motionEvent.getRawY() - initialTouchY));

                        //Update the layout with new X & Y coordinate
                        mWindowManager.updateViewLayout(mFloatingView, params);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }

    //Initialize event handlers for buttons, etc.
    private void initMenuButton(final View view2, final View view3) {
        startimage.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					view2.setVisibility(View.GONE);
					view3.setVisibility(View.VISIBLE);
				}
			});
        kill.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					//FloatingModMenuService.stopSelf();
					// view2.setVisibility(View.VISIBLE)
					view2.setVisibility(View.VISIBLE);
					view2.setAlpha(0);
					view3.setVisibility(View.GONE);
				}
			});
        close.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					view2.setVisibility(View.VISIBLE);
					view2.setAlpha(0.95f);
					view3.setVisibility(View.GONE);
					//Log.i("LGL", "Close");
				}
			});
    }

    private void CreateMenuList() {
        String[] listFT = getFeatureList();
        for (int i = 0; i < listFT.length; i++) {
            final int feature = i;
            String str = listFT[i];
	        if (str.contains("BT_")) {
				addButton(((str.replace("BT_", ""))), new InterfaceBtn() {
						public void OnWrite() {
							Changes(feature, 0);

						}
					});
			} else if (str.contains("To_")) {

				addSwitch(str.replace("To_", ""), new InterfaceBool() {
						public void OnWrite(boolean z) {
							Changes(feature, 0);

						}
                    });
            } else if (str.contains("SB_")) {
                String[] split = str.split("_");
                addSeekBar(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
                        public void OnWrite(int i) {
                            Changes(feature, i);
                        }
                    });
            } else if (str.contains("SBP_")) {
                String[] split = str.split("_");
                addSeekBarSpot(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
                        public void OnWrite(int i) {
                            Changes(feature, i);
                        }
                    });
			} else if (str.contains("SBCor_")) {
                String[] split = str.split("_");
                addESPSeekBarSpot((split[1]), Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
                        public void OnWrite(int i) {
                            Changes(feature, i);
                        }
                    });
            } else if (str.contains("Fuck_")) {
                addCategory(str.replace("Fuck_", ""));
            } else if (str.contains("Fuck2_")) {
                addCategory1(str.replace("Fuck2_", ""));

			}
		};
	}


    private TextView textView2;
    private String featureNameExt;
    private int featureNum;
    private EditTextValue txtValue;

    public class EditTextValue {
        private int val;

        public void setValue(int i) {
            val = i;
        }

        public int getValue() {
            return val;
        }
    }



    private void addCategory(String text) {
        TextView textView = new TextView(this);
        textView.setBackgroundColor(Color.RED);
        textView.setText(Html.fromHtml("<font face='bold'>" + text + "</b></font>"));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.setMargins(0, 5, 0, 10);    
        textView.setGravity(Gravity.CENTER);
        textView.setTextSize(16.0f);       
		android.graphics.drawable.GradientDrawable IJEJGAH = new android.graphics.drawable.GradientDrawable();IJEJGAH.setColor(Color.RED);
		IJEJGAH.setCornerRadii(new float[] { 0, 0, 0, 0, 0, 0, 0, 0 });
		IJEJGAH.setStroke(3, Color.WHITE);
		textView.setBackground(IJEJGAH);
        textView.setTextColor(Color.WHITE);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setPadding(10, 5, 0, 5);


        patches.addView(textView);
    }

	private void addCategory1(String text) {

        TextView textView = new TextView(this);
        LinearLayout.LayoutParams layoutParams7 = new LinearLayout.LayoutParams(-1, -2);
        textView.setBackgroundColor(Color.parseColor("#FF131313"));
        textView.setText(text);
        textView.setGravity(16);
        textView.setLayoutParams(layoutParams7);
        textView.setTextSize(12.0f);
		textView.setPadding(3, 3, 3, 0);
        textView.setTextColor(Color.parseColor("RED"));
        textView.setTypeface(null, Typeface.BOLD);
        patches.addView(textView);
    }

    public void addButton(String feature, final InterfaceBtn interfaceBtn) {
        final Button button = new Button(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, dp(38));
        layoutParams.setMargins(0, 5, 0, 5);
        button.setLayoutParams(layoutParams);
        button.setPadding(0, 0, 0, 0);
        button.setTextSize(15.0f);
        button.setTextColor(Color.parseColor("WHITE"));
        button.setGravity(17);

        if (feature.contains("OnOff_")) {
            feature = feature.replace("OnOff_", "");
            button.setText(Html.fromHtml("<font face='roboto'><b>" + feature + "<font color='#FF0000'></b></font>"));
            button.setBackgroundColor(Color.parseColor("BLACK"));
            button.setGravity(Gravity.LEFT);
            button.setTextColor(Color.parseColor("RED"));
            final String feature2 = feature;
            button.setOnClickListener(new View.OnClickListener() {
                    private boolean isActive = true;

                    public void onClick(View v) {
                        interfaceBtn.OnWrite();
                        if (isActive) {
                            button.setText(Html.fromHtml(("<font face='roboto'><b>" + feature2 + "<font color='#00FF00'></b></font>")));
                            button.setBackgroundColor(Color.parseColor("BLACK"));
                            button.setGravity(Gravity.LEFT);
                            button.setTextColor(Color.parseColor("WHITE"));
                            isActive = false;
                            return;
                        }
                        button.setText(Html.fromHtml("<font face='roboto'><b>" + feature2 + "<font color='#FF0000'></b></font>"));
                        button.setBackgroundColor(Color.parseColor("#000000"));
                        button.setGravity(Gravity.LEFT);
                        button.setTextColor(Color.parseColor("RED"));
                        isActive = true;
                    }
				});

        } else {
            button.setText(feature);
            button.setBackgroundColor(Color.parseColor("#000000"));
            final String feature2 = feature;
            button.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        interfaceBtn.OnWrite();
                    }
                });
        }
        patches.addView(button);

    }

	private void addSwitch(String str, final InterfaceBool sw) {
        final Switch switchR = new Switch(this);
        switchR.setBackgroundColor(Color.parseColor("#00000000"));
        switchR.setText(Html.fromHtml("<font face='roboto'>" + str + " " + "</font>"));
        switchR.setTypeface(null, Typeface.BOLD);
        switchR.setTextColor(Color.parseColor("WHITE"));
        switchR.setPadding(10, 5, 0, 5);       
		switchR.setShadowLayer(5,0,0, Color.RED);

        switchR.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (z) {
                        switchR.setBackgroundColor(Color.parseColor("#00000000")); 
						switchR.setShadowLayer(5,0,0, Color.GREEN);


                    } else {
                        switchR.setBackgroundColor(Color.parseColor("#00000000"));
                        switchR.setShadowLayer(5,0,0, Color.RED);


                    }
                    if (z) {

					} else {

					}
					sw.OnWrite(z);
				}
			});
        patches.addView(switchR);
    }

	private void addSeekBar(final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(17);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setBackgroundColor(Color.TRANSPARENT);
        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='roboto'>" + feature + ": <font color='RED'>" + "0" + "</font>"));
        textView.setTextColor(Color.WHITE);
		textView.setShadowLayer(5,1,1, Color.RED);
		textView.setTypeface(null, Typeface.BOLD);
        SeekBar seekBar = new SeekBar(this);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
		seekBar.getProgressDrawable().setColorFilter(Color.parseColor("#FFBC3300"), PorterDuff.Mode.SRC_IN);
		seekBar.getThumb().setColorFilter(Color.parseColor("#FF009688"), PorterDuff.Mode.SRC_IN);
        seekBar.setMax(max);
        seekBar.setProgress(prog);

        final TextView textView2 = textView;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				public void onStartTrackingTouch(SeekBar seekBar) {
					textView.setShadowLayer(5,0,0, Color.GREEN);
				}

				public void onStopTrackingTouch(SeekBar seekBar) {
					textView.setShadowLayer(5,0,0, Color.RED);
				}

				int l;

				public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
					if (l < i) {

					} else {

					}
					l = i;

					if (i < prog) {
						seekBar.setProgress(prog);
						interInt.OnWrite(prog);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='roboto'>" + feature + ": <font color='RED'>" + prog + "</font>"));

						return;
					}
					interInt.OnWrite(i);
					textView.setText(Html.fromHtml("<font face='roboto'>" + feature + ": " + i + "</font>" + ""));

				}
			});

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        patches.addView(linearLayout);
    }

    private void addSeekBarSpot(final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(17);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setBackgroundColor(Color.TRANSPARENT);
        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='roboto'>" + feature + ": <font color='RED'>" + "OFF" + "</b></font>"));
        textView.setTextColor(Color.WHITE);
		textView.setShadowLayer(5,1,1, Color.RED);
		textView.setTypeface(null, Typeface.BOLD);
        SeekBar seekBar = new SeekBar(this);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
		seekBar.getProgressDrawable().setColorFilter(Color.parseColor("#FFBC3300"), PorterDuff.Mode.SRC_IN);
		seekBar.getThumb().setColorFilter(Color.parseColor("#FF009688"), PorterDuff.Mode.SRC_IN);
        seekBar.setMax(max);
        seekBar.setProgress(prog);

        final TextView textView2 = textView;
        final SeekBar seekBar2 = seekBar;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				public void onStartTrackingTouch(SeekBar seekBar2) {
					textView.setShadowLayer(5,1,1, Color.GREEN);
				}

				public void onStopTrackingTouch(SeekBar seekBar2) {
					textView.setShadowLayer(5,1,1, Color.RED);
				}

				int l;

				public void onProgressChanged(SeekBar seekBar2, int i, boolean z) {
                    if (i == 0) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face='roboto'><b>" + feature + ": <font color='RED'>" + "OFF" + "</b></font>"));
                    } else if (i == 1) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face='roboto'><b>" + feature + ": <font color='roboto'>" + "CABEÇA" + "</b></font>"));
                    } else if (i == 2) {
                        seekBar2.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face='roboto'><b>" + feature + ": <font color='roboto'>" + "CORPO" + "</b></font>"));
                    }
                    interInt.OnWrite(i);
                }
            });

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        patches.addView(linearLayout);
    }


	private void addESPSeekBarSpot(final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(17);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setBackgroundColor(Color.TRANSPARENT);
        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='roboto'>" + feature + ": <font color='RED'>" + "VERMELHO" + "</b></font>"));
        textView.setTextColor(Color.WHITE);
		textView.setShadowLayer(5,1,1, Color.RED);
		textView.setTypeface(null, Typeface.BOLD);
        SeekBar seekBar = new SeekBar(this);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
		seekBar.getProgressDrawable().setColorFilter(Color.parseColor("#FFBC3300"), PorterDuff.Mode.SRC_IN);
		seekBar.getThumb().setColorFilter(Color.parseColor("#FF009688"), PorterDuff.Mode.SRC_IN);
        seekBar.setMax(max);
        seekBar.setProgress(prog);

        final TextView textView2 = textView;
        final SeekBar seekBar2 = seekBar;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				public void onStartTrackingTouch(SeekBar seekBar2) {
				}

				public void onStopTrackingTouch(SeekBar seekBar2) {
				}

				int l;

				public void onProgressChanged(SeekBar seekBar2, int i, boolean z) {
					if (i == 0) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='roboto'><b>" + feature + ": <font color='RED'>" + "VERMELHO" + "</b></font>"));
					} else if (i == 1) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='roboto'><b>" + feature + ": <font color='GREEN'>" + "VERDE" + "</b></font>"));
					} else if (i == 2) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='roboto'><b>" + feature + ": <font color='GRAY'>" + "PRETO" + "</b></font>"));
					} else if (i == 3) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='roboto'><b>" + feature + ": <font color='BLUE'>" + "AZUL" + "</b></font>"));
					} else if (i == 4) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='roboto'><b>" + feature + ": <font color='CYAN'>" + "AZUL" + "</b></font>"));
					} else if (i == 5) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='roboto'><b>" + feature + ": <font color='PURPLE'>" + "ROXO" + "</b></font>"));
					} else if (i == 6) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='roboto'><b>" + feature + ": <font color='YELLOW'>" + "AMARELO" + "</b></font>"));
					} else if (i == 7) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='roboto'><b>" + feature + ": <font color='WHITE'>" + "BRANCO" + "</b></font>"));
					} else if (i == 8) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='roboto'><b>" + feature + ": <font color='MAGENTA'>" + "ROSA" + "</b></font>"));
					} else if (i == 9) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='roboto'><b>" + feature + ": <font color='#FFC0CB'>" + "ROSA" + "</b></font>"));
					} else if (i == 10) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='roboto'><b>" + feature + ": <font color='#d4af37'>" + "LARANJA" + "</b></font>"));
					} else if (i == 11) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face='roboto'><b>" + feature + ": <font color='#4B0082'>" + "INDIGO" + "</b></font>"));
					}
					interInt.OnWrite(i);
				}
			});

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        patches.addView(linearLayout);
    }


    boolean delayed;



    public boolean isViewCollapsed() {
        return mFloatingView == null || mCollapsed.getVisibility() == View.VISIBLE;
    }

    //For our image a little converter
    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

    //Destroy our View
    public void onDestroy() {
        super.onDestroy();

        if (view2 != null) {
            this.mWindowManager.removeView(view2);
        }
        View view = mFloatingView;
        if (view != null) {
            mWindowManager.removeView(view);
        }
    }

    // checking if any network connection / internet available

    // calling our AsyncTask Function that will do thee thing on fetching data from out host file

    // this is the checking one, this will draw our menu if it's license still valid or active

    //Check if we are still in the game. If now our Menu and Menu button will dissapear
    private boolean isNotInGame() {
        RunningAppProcessInfo runningAppProcessInfo = new RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance != 100;
    }

    //Same as above so it wont crash in the background and therefore use alot of Battery life


    private interface InterfaceBtn {
        void OnWrite();
    }

    private interface InterfaceInt {
        void OnWrite(int i);
    }

    private interface InterfaceBool {
        void OnWrite(boolean z);
    }

    private interface InterfaceStr {
        void OnWrite(String s);
    }
}

